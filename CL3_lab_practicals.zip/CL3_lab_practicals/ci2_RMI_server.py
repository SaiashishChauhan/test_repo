import Pyro4

@Pyro4.expose
class StringConcatenationServer:
    def concatenate_strings(self, str1, str2):
        return str1 + str2

def main():
    # Create a Pyro daemon and locate the nameserver
    daemon = Pyro4.Daemon(host="127.0.0.1")  # Explicitly bind to localhost
    ns = Pyro4.locateNS(host="127.0.0.1", port=9090)  # Locate Pyro nameserver

    # Create an instance of the server class
    server = StringConcatenationServer()

    # Register the server object with the Pyro daemon
    uri = daemon.register(server)

    # Register the object with a name in the nameserver
    ns.register("string.concatenation", uri)

    print("Server URI:", uri)

    # Save URI to a file for client access
    with open("server_uri.txt", "w") as f:
        f.write(str(uri))

    print("Server is running...")
    daemon.requestLoop()  # Start the event loop

if __name__ == "__main__":
    main()
