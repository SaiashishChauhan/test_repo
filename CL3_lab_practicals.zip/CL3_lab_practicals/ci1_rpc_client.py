import xmlrpc.client

# Connect to the server
server = xmlrpc.client.ServerProxy("http://localhost:8000/")

# Take user input
n = int(input("Enter a non-negative integer: "))

# Call the remote factorial function
result = server.factorial(n)

# Print the result
print(f"Factorial of {n} is {result}")
