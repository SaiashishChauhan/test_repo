import multiprocessing
import re
from collections import Counter

# Function to read input file
def read_file(filename):
    with open(filename, 'r', encoding='utf-8') as f:
        return f.read()

# Mapper function for character count
def char_mapper(text_chunk):
    return Counter(text_chunk.replace(" ", ""))  # Removing spaces

# Mapper function for word count (FIXED)
def word_mapper(text_chunk):
    words = re.findall(r'\b\w+\b', text_chunk.lower())  # Extract full words
    return Counter(words)

# Reducer function
def reducer(counts_list):
    final_counts = Counter()
    for count in counts_list:
        final_counts.update(count)
    return final_counts

# Function to split text into properly sized chunks
def split_text_into_chunks(text, num_chunks):
    words = re.findall(r'\b\w+\b', text)  # Extract full words
    num_chunks = min(num_chunks, len(words))  # Ensure num_chunks is not greater than words
    chunk_size = max(1, len(words) // num_chunks)  # Avoid zero chunk_size

    chunks = [words[i:i + chunk_size] for i in range(0, len(words), chunk_size)]
    return [" ".join(chunk) for chunk in chunks]  # Convert lists of words back to strings

# Main MapReduce Function (Fixed)
def mapreduce(filename, mapper_func):
    text = read_file(filename)
    num_workers = min(multiprocessing.cpu_count(), len(text))  # Set a reasonable worker count
    chunks = split_text_into_chunks(text, num_workers)  # Use fixed chunking method

    with multiprocessing.Pool(processes=num_workers) as pool:
        mapped_results = pool.map(mapper_func, chunks)
    
    return reducer(mapped_results)

if __name__ == "__main__":
    filename = "sample.txt"  # Change if using a different file
    
    # Character Count
    char_counts = mapreduce(filename, char_mapper)
    print("Character Count:")
    print(char_counts)
    
    # Word Count
    word_counts = mapreduce(filename, word_mapper)
    print("\nWord Count:")
    print(word_counts)
