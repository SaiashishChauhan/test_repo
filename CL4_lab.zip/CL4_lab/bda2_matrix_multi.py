import multiprocessing
import numpy as np

# Function to take matrix input from user
def input_matrix(rows, cols, name):
    print(f"Enter matrix {name} ({rows}x{cols}):")
    matrix = []
    for i in range(rows):
        row = list(map(int, input(f"Row {i + 1}: ").split()))
        if len(row) != cols:
            raise ValueError(f"Each row must have {cols} elements!")
        matrix.append(row)
    return np.array(matrix)

# Mapper function to compute partial dot products
def matrix_multiply_mapper(args):
    row, B = args  # Unpack row of A and matrix B
    return [sum(a * b for a, b in zip(row, col)) for col in zip(*B)]  # Compute row of C

# Reducer function to collect results
def matrix_multiply_reducer(results):
    return np.array(results)

# MapReduce function for matrix multiplication
def mapreduce_matrix_multiplication(A, B):
    num_workers = min(multiprocessing.cpu_count(), len(A))  # Define parallel workers

    with multiprocessing.Pool(processes=num_workers) as pool:
        mapped_results = pool.map(matrix_multiply_mapper, [(row, B) for row in A])

    return matrix_multiply_reducer(mapped_results)

if __name__ == "__main__":
    # Take matrix dimensions as input
    ROWS_A = int(input("Enter number of rows for Matrix A: "))
    COLS_A = int(input("Enter number of columns for Matrix A: "))
    ROWS_B = int(input("Enter number of rows for Matrix B: "))
    COLS_B = int(input("Enter number of columns for Matrix B: "))

    # Ensure matrix dimensions are valid for multiplication (COLS_A == ROWS_B)
    if COLS_A != ROWS_B:
        raise ValueError("Matrix multiplication not possible! Number of columns in A must match rows in B.")

    # Take matrix input from the user
    A = input_matrix(ROWS_A, COLS_A, "A")
    B = input_matrix(ROWS_B, COLS_B, "B")

    print("\nMatrix A:")
    print(A)
    print("\nMatrix B:")
    print(B)

    # Perform MapReduce-based matrix multiplication
    C = mapreduce_matrix_multiplication(A, B)

    print("\nResultant Matrix C (A x B):")
    print(C)
