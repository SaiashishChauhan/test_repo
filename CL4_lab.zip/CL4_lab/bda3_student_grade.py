import multiprocessing

# Function to take student data input
def input_students():
    num_students = int(input("Enter number of students: "))
    students = []
    for _ in range(num_students):
        name = input("Enter student name: ")
        marks = float(input(f"Enter marks for {name}: "))
        students.append((name, marks))
    return students

# Mapper function - Assigns grades based on marks
def grade_mapper(student):
    name, marks = student
    if marks >= 90:
        grade = "A+"
    elif marks >= 80:
        grade = "A"
    elif marks >= 70:
        grade = "B"
    elif marks >= 60:
        grade = "C"
    elif marks >= 50:
        grade = "D"
    else:
        grade = "F"
    return (name, grade)

# Reducer function - Collects results into a dictionary
def grade_reducer(mapped_results):
    return dict(mapped_results)

# MapReduce function
def mapreduce_student_grades(students):
    num_workers = min(multiprocessing.cpu_count(), len(students))

    with multiprocessing.Pool(processes=num_workers) as pool:
        mapped_results = pool.map(grade_mapper, students)

    return grade_reducer(mapped_results)

if __name__ == "__main__":
    # Input student data
    students = input_students()

    print("\nCalculating Grades...\n")
    
    # Compute grades using MapReduce
    student_grades = mapreduce_student_grades(students)

    # Display results
    print("Student Grades:")
    for student, grade in student_grades.items():
        print(f"{student}: {grade}")
