import multiprocessing
import re
from collections import Counter

# Function to read input file
def read_file(filename):
    with open(filename, 'r', encoding='utf-8') as f:
        return f.read()

# Mapper function to count word occurrences in each chunk
def word_frequency_mapper(args):
    text_chunk, target_word = args
    words = re.findall(r'\b\w+\b', text_chunk.lower())  # Extract full words
    return Counter(words)[target_word]  # Count target word

# Reducer function to sum up all partial counts
def reducer(counts_list):
    return sum(counts_list)

# Function to split text into chunks
def split_text_into_chunks(text, num_chunks):
    words = re.findall(r'\b\w+\b', text)  # Extract words
    num_chunks = min(num_chunks, len(words))  # Ensure valid chunk count
    chunk_size = max(1, len(words) // num_chunks)  # Avoid zero chunk_size

    chunks = [" ".join(words[i:i + chunk_size]) for i in range(0, len(words), chunk_size)]
    return chunks

# Main MapReduce Function
def mapreduce(filename, target_word):
    text = read_file(filename)
    num_workers = min(multiprocessing.cpu_count(), len(text))  # Set a reasonable worker count
    chunks = split_text_into_chunks(text, num_workers)  # Create chunks
    
    with multiprocessing.Pool(processes=num_workers) as pool:
        mapped_results = pool.map(word_frequency_mapper, [(chunk, target_word) for chunk in chunks])
    
    return reducer(mapped_results)

if __name__ == "__main__":
    filename = "sample_bda1.txt"  # Change this to your text file
    target_word = "mapreduce"  # Change this to the word you want to count

    # Calculate word frequency using MapReduce
    word_frequency = mapreduce(filename, target_word.lower())

    print(f"Frequency of '{target_word}': {word_frequency}")
